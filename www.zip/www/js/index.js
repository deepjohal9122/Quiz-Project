(function(){
    var data = {
        quizContent: [
            {
                 "question": "Which mobile platform is not supported by Cordova?",
                "answer1": "Android",
                "answer2": "iOS",
                "answer3": "Blackberry",
               
                fact:"The correct answer is iOS",
                correctAnswer: 2
            },
            {
               "question": "Which Cordova version introduced Cordova CLI?",
                "answer1": "4",
                "answer2": "3",
                "answer3": "2",
                
                fact:"The correct answer is 4",
                
                correctAnswer: 1
            },
{
                "question":  "What is the typical filename of startup page file of an Cordova application?",
                "answer1": "index.html",
                "answer2": "config.htm",
                "answer3": "index.htm",
              
                fact:"The correct answer is index.html",
                correctAnswer: 1
            },

 {
               "question": "Which directory is created by default with adding of platform support?",
                "answer1": "web",
                "answer2": "http",
                "answer3": "usr",
                
                fact:"The correct answer is usr",
                
                correctAnswer: 3
            },
             {
               "question": "Which of the following command removes a plugin from the project as per their their identifier?",
                "answer1": "Cordova plugin discard",
                "answer2": "Cordova plugin delete",
                "answer3": "Cordova plugin remove",
                
                fact:"The correct answer is Cordova plugin delete",
                
                correctAnswer: 2
            },
             {
               "question": "Which file provides information about the app and specifies parameters affecting how it works?",
                "answer1": "index.html",
                "answer2": "conf.xml",
                "answer3": "config.xml",
                
                fact:"The correct answer is index.html",
                
                correctAnswer: 1
            },
             {
               "question": "Which type of license does Cordova project is under?",
                "answer1": "Propritory",
                "answer2": "Apache license",
                "answer3": "BSD license",
                
                fact:"The correct answer is Propritory",
                
                correctAnswer: 1
            },
             {
               "question": "Which of the following platform tools used to package Cordova application into a native application, runs on a single operating system only?",
                "answer1": "Android SDK",
                "answer2": "Blackberry SDK",
                "answer3": "iOS SDK",
                
                fact:"The correct answer is iOS SDK",
                
                correctAnswer: 3
            },
             {
               "question": "What technology does Cordova uses for cross platform mobile application development?",
                "answer1": "CLR",
                "answer2": "Web",
                "answer3": "JVM",
                
                fact:"The correct answer is JVM",
                
                correctAnswer: 3
            },
             {
               "question": "Which workflow type uses Cordova CLI?",
                "answer1": "Cross platform",
                "answer2": "Platform centered",
                "answer3": "Platform oriented",
                
                fact:"The correct answer is Platform centered",
                
                correctAnswer: 2
            },
             {
               "question": "Which Cordova CLI command prepares and then packages web applications into native Cordova applications?",
                "answer1": "Prepare",
                "answer2": "Package",
                "answer3": "Generate",
                
                fact:"The correct answer is Generate",
                
                correctAnswer: 3
            },
             {
               "question": "Which Cordova CLI command. runs a Cordova application in one or more mobile device  platform's device?",
                "answer1": "Emulate",
                "answer2": "sudo",
                "answer3": "run",
                
                fact:"The correct answer is sudo",
                
                correctAnswer: 2
            },
             {
               "question": "Which Cordova CLI command option display information about progress?",
                "answer1": "-d",
                "answer2": "-log",
                "answer3": "-e",
                
                fact:"The correct answer is -d",
                
                correctAnswer: 1
            },
             {
               "question": "Which of the following command search plugins as their identifier?",
                "answer1": "Cordova plugin find",
                "answer2": "Cordova plugin list",
                "answer3": "Cordova plugin search",
                
                fact:"The correct answer is Cordova plugin search",
                
                correctAnswer: 3
            },
             {
               "question": "Which command will remove the Blackberry10 platform?",
                "answer1": "Cordova platform uninstall",
                "answer2": "Cordova platform move",
                "answer3": "Cordova platform remove",
                
                fact:"The correct answer is Cordova platform uninstall",
                
                correctAnswer: 1
            },
             {
               "question": "Which of the following command add platform support for iOS?",
                "answer1": "Cordova platform add ios-app",
                "answer2": "Cordova platform add iOS-app",
                "answer3": "Cordova platform add iOS",
                
                fact:"The correct answer is Cordova platform iOS-app",
                
                correctAnswer: 2
            },

 {
               "question": "Which Cordova CLI command, manages the installation and uninstallation of Cordova plugins?",
                "answer1": "Plugin",
                "answer2": "Install",
                "answer3": "Append",
                
                fact:"The correct answer is Append",
                
                correctAnswer: 3
            },


            {
                "question":  "What is the third argument, if provided with create Cordova CLI command?",
                "answer1": "File",
                "answer2": "Application title",
                "answer3": "Directory",
              
                fact:"The correct answer is Application title",
                correctAnswer: 2
            },
            {
                question: "Which command produces a listing of potentially useful details, such as currently installed platforms and plugins, SDK versions for each platform, and versions of the CLI and node.js?",
                answer1: "info",
                answer2: "list",
                answer3: "status",
                fact:"The correct answer is status",
                correctAnswer: 3
            },
            {
                question  : "Which Cordova application's directory, has the applications form page?",
                answer1  : "usr",
                answer2  : "http",
                answer3  : "www",
                fact:"The correct answer is usr",
                correctAnswer: 1
                  }
        ],
        points: 0
    };
    
    var display = {
        getApp: document.getElementById('app'),

        // Updates DOM on start/restart of the quiz
        mainPage: function() {
            var newEl = '<div class="quest-number"><p id="questNumber"></p></div><h1 id="questionDisplay" class="h3"></h1>';
                newEl += '<ul><li><label><input type="radio" name="answers" id="input1" value="1"><span class="outer"><span class="inner"></span></span><div id="answerDisplay1"></div></label></li>';
                newEl += '<li><label><input type="radio" name="answers" id="input2" value="2"><span class="outer"><span class="inner"></span></span><div id="answerDisplay2"></div></label></li>';
                newEl += '<li><label><input type="radio" name="answers" id="input3" value="3"><span class="outer"><span class="inner"></span></span><div id="answerDisplay3"></div></label></li></ul>';
                newEl += '<div class="points-wrap"><p id="currentPoints"></p></div>';

            this.getApp.innerHTML = newEl;
        },

        // Updates DOM with each question
        updateMainPage: function() {
            var getQuestNumber = document.getElementById('questNumber'),
                getQuestion = document.getElementById('questionDisplay'),
                getAnswer1 = document.getElementById('answerDisplay1'),
                getAnswer2 = document.getElementById('answerDisplay2'),
                getAnswer3 = document.getElementById('answerDisplay3'),
               
                getCurrentPoints = document.getElementById('currentPoints'),
                sumOfQuestions = data.quizContent.length;
                
            getQuestNumber.innerHTML = control.count + 1 + '/' + sumOfQuestions;
            getQuestion.innerHTML = data.quizContent[control.count].question;
            getAnswer1.innerHTML = data.quizContent[control.count].answer1;
            getAnswer2.innerHTML = data.quizContent[control.count].answer2;
            getAnswer3.innerHTML = data.quizContent[control.count].answer3;
         
            getCurrentPoints.innerHTML = 'Score:' + ' ' + data.points;
            this.newElement('button', 'submit', 'Submit');
        },
        addAnswer: function(showMessage) {
            var sumOfQuestions = data.quizContent.length;

            if(showMessage === 'correct') {
                this.newElement('p', 'showAnswer', 'Correct Answer!');
            } else {
                var x=data.quizContent[control.count].fact    
                this.newElement('p', 'showAnswer', 'Incorrect..!  '+x );
            }

            if (control.count < sumOfQuestions - 1) {
                this.newElement('button', 'nextQuest', 'Next');
            } else {
                this.newElement('button', 'result', 'Check your result');
            }
        },
        removeAnswer: function(event) {
            var getShowAnswer = document.getElementById('showAnswer');
            var getShowAnswerParent = getShowAnswer.parentNode;
            getShowAnswerParent.removeChild(getShowAnswer);
            var clickedEl = event.target;
            var clickedElParent = clickedEl.parentNode;
            clickedElParent.removeChild(clickedEl);
            var radioButtons = document.getElementsByName('answers');
            var allRadioButtons = radioButtons.length;
            var i;

            for(i = 0; i < allRadioButtons; i++) {
                radioButtons[i].checked = false;
            }
        },

        // Displays final page of the quiz
        resultPage: function() {
            this.getApp.innerHTML = '<h1 class="h3">You have ' + data.points + ' question(s) answered correctly</h1>';
            this.newElement('button', 'restart', 'Start again');
        },
        newElement: function(elem, elemId, elemText) {
            var newElem = document.createElement(elem);
            var newElemText = document.createTextNode(elemText);
            newElem.appendChild(newElemText);
            newElem.id = elemId;
            this.getApp.appendChild(newElem);
        }
    };
    var control = {
        init: function() {
            var start = document.getElementById('start') || document.getElementById('restart');
            start.addEventListener('click', function() {
                display.mainPage();
                control.update();
            }, false);
        },
        update: function() {
            display.updateMainPage();
            var submit = document.getElementById('submit');
            submit.addEventListener('click', this.checkAnswer, false);
        },

        /**
        * Alerts if none of the radios is checked on submit 
        * Verifies correct/incorrect answer
        * Directs quiz to the next question or to the final page
        */
        checkAnswer: function(event) {
            var radioButtons = document.getElementsByName('answers'),
                allRadioButtons = radioButtons.length,
                isChecked = false,
                checkedRadio,
                clickedEl = event.target,
                clickedElParent = clickedEl.parentNode,
                i;

            for (i = 0; i < allRadioButtons; i++) {
                if (radioButtons[i].checked) {
                    isChecked = true;
                    checkedRadio = +radioButtons[i].value;
                }
            }

            if (isChecked === false) {
                alert('Please choose the answer!');
            } else {
                clickedElParent.removeChild(clickedEl);
                if (checkedRadio === data.quizContent[control.count].correctAnswer) {
                    display.addAnswer('correct');
                    data.points++;
                } else {
                    display.addAnswer();
                }

                var nextQuestion = document.getElementById('nextQuest'),
                    result = document.getElementById('result');

                if (nextQuestion) {
                    nextQuestion.addEventListener('click', function(event) {
                        control.count++;
                        display.removeAnswer(event);
                        control.update();
                    }, false);
                } else {
                    result.addEventListener('click', function() {
                        display.resultPage();
                        control.init();
                        control.count = 0;
                        data.points = 0;
                    }, false);
                }
            }
        },

        // Used for incrementing/looping through the quiz questions and answers
        count: 0
    };

    control.init();

})();
